package com.example.virtualdisplay2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity  {

    private static final String TAG = "mytag";
    private static final int REQUEST_CODE= 100;
    private MediaProjectionManager mProjectionManager;
    private MediaProjection mProjection;
    private ImageReader mImageReader;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private int imagesProduced;
    private long startTimeInMillis;
    VirtualDisplay mVirtualDisplay;
    SurfaceView surfaceView;
    Surface mSurface;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG,"on create");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        mSurface = surfaceView.getHolder().getSurface();
        int mWidth = surfaceView.getLayoutParams().width;
        int mHeight = surfaceView.getLayoutParams().height;
        // call for the projection manager
        mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        // start projection
        final Button startButton = (Button)findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.d(TAG,"startButtonOnClick");
                startProjection();
            }
        });

        // stop projection
        final Button stopButton = (Button)findViewById(R.id.stopButton);
        stopButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.d(TAG,"StopButtonOnClick");
                stopProjection();
            }
        });

        // start capture handling thread
        new Thread() {
            @Override
            public void run() {
                Looper.prepare();
                mHandler = new Handler();
                Looper.loop();
            }
        }.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            // for statistics -- init

            imagesProduced = 0;
            startTimeInMillis = System.currentTimeMillis();
            Log.d(TAG,"startActivityResult");
            mProjection = mProjectionManager.getMediaProjection(resultCode, data);
            Log.d(TAG,"startActivityResultmproject");

            if (mProjection != null) {
                final DisplayMetrics metrics = getResources().getDisplayMetrics();
                final int density = metrics.densityDpi;
                final int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY | DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
                final Display display = getWindowManager().getDefaultDisplay();
                final Point size = new Point();
                display.getSize(size);
                final int width = size.x;
                final int height = width;


                mImageReader = ImageReader.newInstance(width, height, ImageFormat.JPEG, 2);
                mVirtualDisplay=mProjection.createVirtualDisplay("screencap",
                        width,
                        height,
                        density,
                        flags,
                        mImageReader.getSurface(),
                        new VirtualDisplayCallback(),
                        mHandler);
                mProjection.createVirtualDisplay("screencap",
                        width,
                        height,
                        density,
                        flags,
                        mSurface,
                        null,
                        null);

                Log.d(TAG,"after create virtual display");
                mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {

                    @Override
                    public void onImageAvailable(ImageReader reader) {
                        Log.d(TAG,"startImageAvailable");
                        Image image = null;
                        FileOutputStream fos = null;
                        Bitmap bitmap = null;

                        try {
                            Log.d(TAG,"Try");
                            image = mImageReader.acquireLatestImage();
                            if (image != null) {
                                Log.d(TAG,"Image is null");
                                final Image.Plane[] planes = image.getPlanes();
                                Log.d(TAG,"Image planes");
                                final Buffer imageBuffer = planes[0].getBuffer().rewind();

                                // create bitmap
                                Log.d(TAG,"Create bitmap");
                                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                                bitmap.copyPixelsFromBuffer(imageBuffer);
                                // write bitmap to a file
                                String filePath = Environment.getExternalStorageDirectory()+"/Download/"+ Calendar.getInstance().getTime().toString()+".jpg";
                                Log.d(TAG,filePath);
                                File fileScreenshot = new File(filePath);
                                FileOutputStream fileOutputStream = null;
                                final long now = System.currentTimeMillis();
                                /*Log.d(TAG,"write bitmap");
                                fos = new FileOutputStream(filePath);*/
                                fileOutputStream = new FileOutputStream(fileScreenshot);


                                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                                // bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);

                                // for statistics
                                imagesProduced++;

                                final long sampleTime = now - startTimeInMillis;
                                Log.e(TAG, "produced images at rate: " + (imagesProduced/(sampleTime/1000.0f)) + " per sec");
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            if (fos!=null) {
                                try {
                                    fos.close();
                                } catch (IOException ioe) {
                                    ioe.printStackTrace();
                                }
                            }

                            if (bitmap!=null)
                                bitmap.recycle();

                            if (image!=null)
                                image.close();

                        }
                    }

                }, mHandler);
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void startProjection() {
        Log.d(TAG,"startProjection");
        Intent serviceIntent = new Intent(this, MyForegroundService.class);
        serviceIntent.putExtra("inputExtra", "Foreground Service Example in Android");
        ContextCompat.startForegroundService(this, serviceIntent);
        startActivityForResult(mProjectionManager.createScreenCaptureIntent(), REQUEST_CODE);
    }

    private void stopProjection() {
        Log.d(TAG,"stopProjection");
        if (mVirtualDisplay != null) {
            Log.d(TAG, "destroyVirtualDisplay release");
            mVirtualDisplay.release();
            mVirtualDisplay = null;
        }
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mProjection.stop();
            }
        });
    }


    private class VirtualDisplayCallback extends VirtualDisplay.Callback {

        @Override
        public void onPaused() {
            super.onPaused();
            Log.e(TAG, "VirtualDisplayCallback: onPaused");
        }

        @Override
        public void onResumed() {
            super.onResumed();
            Log.e(TAG, "VirtualDisplayCallback: onResumed");
        }

        @Override
        public void onStopped() {
            super.onStopped();
            Log.e(TAG, "VirtualDisplayCallback: onStopped");
        }

    }
    
}

